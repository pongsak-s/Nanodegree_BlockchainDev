(function() {
    MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
    const ACCUMULATE_EXP = [
        0, 0, 16, 33, 51, 70, 90, 112, 136, 162, 190, 
        220, 253, 289, 328, 370, 416, 466, 521, 581, 647, 
        719, 798, 884, 978, 1081, 1194, 1318, 1454, 1603, 1766, 
        1944, 2138, 2349, 2578, 2826, 3094, 3383, 3694, 4028, 4386, 
        4769, 5178, 5614, 6078, 6571, 7094, 7648, 8234, 8853, 9506, 
        10194, 10918, 11679, 12478, 13316, 14194, 15113, 16074, 17078, 18126, 
        19219, 20358, 21544, 22778, 24061, 25394, 26778, 28214, 29703, 31246, 
        32844, 34498, 36209, 37978, 39806, 41694, 43643, 45654, 47728, 49866, 
        52069, 54338, 56674, 59078, 61551, 64094, 66708, 69394, 72153, 74986, 
        77894, 80878, 83939, 87078, 90296, 93594, 96973, 100434, 103978, 107606, 
        111319, 115118, 119004, 122978, 127041, 131194, 135438, 139774, 144203, 148726, 
        153344, 158058, 162869, 167778, 172786, 177894, 183103, 188414, 193828, 199346, 
        204969, 210698, 216534, 222478, 228531, 234694, 240968, 247354, 253853, 260466, 
        267194, 274038, 280999, 288078, 295276, 302594, 310033, 317594, 325278, 333086, 
        341019, 349078, 357264, 365578, 374021, 382594, 391298, 400134, 409103, 418206, 
        427444
    ];
    const Element = {
        Fire: "fire",
        Earth: "earth",
        Lightning: "lightning",
        Water: "water",
        Power: "power"
    };
    const WEAPON_CONTRACT_API = "https://bsc-mainnet.web3api.com/v1/RFSG2J6W6AS9JIBS9MWUTEHZ2MYMXQK6QJ";
    const WEAPON_CONTRACT_ADDRESS = "0x7e091b0a220356b157131c831258a9c98ac8031a";
    const MethodId = {
        getBonusPower: "0xae5d498e"        
    };
    var apiCallId = 1;
    var lastWeaponId = 0;
    var lastWeaponBonusPower = 0;

    function convertToHex(num, len = 64) {
        var str = num.toString(16);
        return "0".repeat(Math.max(len - str.length, 0)) + str;
    }

    function createReqData(methodId, ...datas) {
        var req = {
            jsonrpc: "2.0",
            id: apiCallId++,
            method: "eth_call"
        };

        datas.map(d => convertToHex(d)).concat();

        var params = [
            {
                from: "0x0000000000000000000000000000000000000000",
                data: methodId + datas.map(d => convertToHex(d)).concat(),
                to: WEAPON_CONTRACT_ADDRESS
            },
            "latest"
        ];

        return { ...req, params };
    }

    function getBonusPower(weaponId, callback) {
        if (lastWeaponId == weaponId) {
            callback(lastWeaponBonusPower);
            return;
        };

        var xhr = new XMLHttpRequest();
        xhr.open("POST", WEAPON_CONTRACT_API, true);
        xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhr.onreadystatechange = function() {
          if (xhr.readyState == 4) {
            var data = JSON.parse(xhr.responseText);
            //console.log(data);
            var power = parseInt(data.result, 16);
            lastWeaponId = weaponId;
            lastWeaponBonusPower = power;
            callback(power);
          }
        }
        var req = createReqData(MethodId.getBonusPower, weaponId);
        //console.log(req);
        xhr.send(JSON.stringify(req));
    }

    function numberWithCommas(x) {
        return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    function computeTraitBonus(hTrait, wTrait, eTrait) {
        var power = 1;
        power += hTrait == wTrait ? 0.075 : 0;
        power += (hTrait == Element.Fire && eTrait == Element.Earth) || 
            (hTrait == Element.Earth && eTrait == Element.Lightning) || 
            (hTrait == Element.Lightning && eTrait == Element.Water) || 
            (hTrait == Element.Water && eTrait == Element.Fire) ? 0.075 : 0;
        power -= (hTrait == Element.Fire && eTrait == Element.Water) ||
            (hTrait == Element.Earth && eTrait == Element.Fire) ||
            (hTrait == Element.Lightning && eTrait == Element.Earth) ||
            (hTrait == Element.Water && eTrait == Element.Lightning) ? 0.075 : 0;

        return power;
    }

    function computeWeaponPower(wTrait, sTrait, sValue) {
        return sValue * (wTrait == sTrait && 0.002675 || sTrait == Element.Power && 0.002575 || 0.0025);
    }

    function rollPower(power, bonus) {
        var minPower = Math.ceil(power * 0.9);
        var maxPower = Math.floor(power * 1.1);
        return (Math.floor(Math.random() * (maxPower - minPower + 1)) + minPower) * bonus;
    }

    function waitForAddedNode(params) {
        new MutationObserver(function(mutations) {
            var el = document.getElementsByClassName(params.className)[0];
            if (el) {
                this.disconnect();
                params.done(el);
            }
        }).observe(params.parent || document, {
            subtree: !!params.recursive || !params.parent,
            childList: true,
        });
    }

    waitForAddedNode({
        className: 'character-data-column',
        parent: document.querySelector('.character-data-column'),
        done: function(el) {
            var observe = new MutationObserver((m, o) => {
                m.some((d) => {
                    if (d.target.nodeType == Node.TEXT_NODE && d.target.parentNode.classList.contains("character-name")) {
                        var spnNextLvl = document.querySelector(".milestone-lvl-text");
                        var divCharacter = document.querySelector(".character-data-column");
                        var spnSubtext = divCharacter.querySelector('.subtext-stats');
                        var spnStats = spnSubtext.querySelectorAll(".subtext-stats > span");

                        var [allText, lvlText, expText] = spnStats[0].innerText.match(/^\s*(\d+)\s+\((\d+)\s+\/\s+\d+\s+xp\)\s*$/i);
                        var [allText, nextLvlText] = spnNextLvl.innerText.match(/^lvl\s+(\d+)$/i);
                        var curLevel = parseInt(lvlText.replace(/\,/g, ''), 10);
                        var curExp = parseInt(expText.replace(/\,/g, ''), 10);
                        var nextLevel = parseInt(nextLvlText.replace(/\,/g, ''), 10);
                        var needExp = ACCUMULATE_EXP[nextLevel] - ACCUMULATE_EXP[curLevel] - curExp;

                        var spnExt = spnNextLvl.parentNode.querySelector(".milestone-lvl-exp");
                        if (!spnExt) {
                            spnExt = spnNextLvl.cloneNode(true);
                            spnExt.className = "milestone-lvl-exp";
                            spnNextLvl.parentNode.insertBefore(spnExt, spnNextLvl.nextSibling);
                        }
                        spnExt.innerText = " (" + numberWithCommas(needExp) + " XP more)"

                        return true;
                    }
                });
            });

            observe.observe(el, {
                subtree: true,
                characterData: true
            });
        }
    });

    function computeRollPower() {
        var divHeroPower = document.querySelector(".subtext.subtext-stats").children[3];
        var divHeroTrait = document.querySelector(".character-name").children[0];
        var ddlStamina = document.querySelector("select.custom-select");

        var divWeapon = document.querySelector(".header-row > .weapon-icon-wrapper");
        if (!divWeapon) return;

        //var divWeaponId = divWeapon.querySelector(".id");
        var divWeaponTrait = divWeapon.querySelector(".trait");
        var divWeaponStats = divWeapon.querySelector(".stats");
        //var divWeaponBonusPower = divWeapon.querySelector(".bonus-power");

        var heroPower = parseInt(divHeroPower.innerText.replace(/\,/g, ''), 10);
        var heroTrait = divHeroTrait.className.match(/(fire|earth|lightning|water)-icon/i)[1];
        //var weaponId = parseInt(divWeaponId.innerText.match(/^id\s+(\d+)$/i)[1], 10);
        var weaponTrait = divWeaponTrait.firstChild.className.match(/^(\w+)-icon$/i)[1];

        var weaponBonus = showWeaponBonusPower(divWeapon, true);
        var weaponPower = 0;
        var stamina = ddlStamina.value | 0;

        // var weaponLB = { LB: 0, "4B": 0, "5B": 0 };
        // divWeaponBonusPower.querySelectorAll("div > span").forEach(d => {
        //     if (d.classList.contains("bonus-power-ext")) return;
        //     var lbMatch = d.innerText.match(/^(\d+)\s+(\w+)$/);
        //     if (lbMatch.length == 3) {
        //         var key = lbMatch[2];
        //         var value = parseInt(lbMatch[1], 10);
        //         weaponLB[key] = weaponLB[key] + value;
        //     }
        // });
        // //console.log(weaponLB);
        // weaponBonus = weaponLB["LB"] * 15 + weaponLB["4B"] * 30 + weaponLB["5B"] * 60;
        // if (weaponBonus) {
        //     var spnWeaponBonus = divWeaponBonusPower.querySelector("div > span.bonus-power-ext");
        //     if (!spnWeaponBonus) {
        //         var divWeaponBonus = divWeaponBonusPower.querySelector("div").cloneNode(true);
        //         spnWeaponBonus = divWeaponBonus.querySelector("span");
        //         spnWeaponBonus.classList.add("bonus-power-ext");
        //         divWeaponBonusPower.insertAdjacentElement("afterbegin", divWeaponBonus);
        //     }

        //     spnWeaponBonus.innerText = weaponBonus + " BP";
        // }

        divWeaponStats.querySelectorAll("div").forEach(d => {
            [z, t, p] = d.lastChild.innerText.match(/^(\w+)\s+\+(\d+)$/i);
            t = t.toLowerCase();
            if (t != "bns") { // excludes BONUS POWER;
                p = parseInt(p, 10);
                trait = t == "str" && Element.Fire || t == "dex" && Element.Earth || t == "cha" && Element.Lightning || t == "int" && Element.Water || t == "pwr" && Element.Power;
                weaponPower += computeWeaponPower(weaponTrait, trait, p);
            }
        });

        //console.log(weaponPower, heroPower, weaponBonus);
        heroPower = (1 + weaponPower) * heroPower + weaponBonus;
        [heroMinPower, heroMaxPower] = [Math.ceil(heroPower * 0.9), Math.floor(heroPower * 1.1)];

        document.querySelectorAll(".encounter-container").forEach((d) => {
            var divPower = d.querySelector(".encounter-power");
            var divExp = d.querySelector(".xp-gain");
            var spnTrait = d.querySelector(".encounter-element").firstChild;

            var enemyPower = parseInt(divPower.innerText.match(/^\s*(\d+)\spower\s*$/i)[1], 10);
            var enemyTrait = spnTrait.className.match(/^(\w+)-icon$/i)[1];
            var enemyMinPower = Math.ceil(enemyPower * 0.9);
            var enemyMaxPower = Math.floor(enemyPower * 1.1);
            //console.log(divExp.innerText);
            var enemyExp = parseInt(divExp.innerText.trim().match(/^\+(\d+)\s+xp(.*)$/i)[1], 10);
            var enemyExpBase = enemyExp / stamina;

            // var divExpDetail = d.querySelector(".xp-gain-desc");
            // if (!divExpDetail) {
            //     divExpDetail = divExp.cloneNode(true);
            //     divExpDetail.className = "xp-gain-desc";
            //     divExp.insertAdjacentElement('afterend', divExpDetail);
            // }

            var divExpExt = d.querySelector(".xp-gain-ext");
            if (!divExpExt) {
                divExpExt = divExp.cloneNode(true);
                divExpExt.className = "xp-gain-ext";
                divExp.insertAdjacentElement('afterend', divExpExt);
            }
            //divExpDetail.innerHTML = "<span>(" + enemyExpBase + " <span>x" + stamina + "</span>)</span>";
            divExpExt.innerHTML = "+" + enemyExp + " XP <span>(" + (enemyExpBase == Infinity ? "??" : enemyExpBase) + ")</span>";  
            //divExpDetail.innerHTML = "<span>x" + stamina + "</span>";

            var traitBonus = computeTraitBonus(heroTrait, weaponTrait, enemyTrait);
            var minRollPower = Math.ceil(heroMinPower * traitBonus);
            var maxRollPower = Math.floor(heroMaxPower * traitBonus);
            //console.log(heroTrait, weaponTrait, enemyTrait, heroMinPower, heroMaxPower, weaponBonus);
            
            var winMatch = 0;
            for (let i = 0; i < 1000; i++) {
                winMatch += rollPower(heroPower, traitBonus) > rollPower(enemyPower, 1) ? 1 : 0;
            }

            var powerRangeNode = d.querySelector(".encounter-power-range");
            if (!powerRangeNode) {
                powerRangeNode = divExp.cloneNode(true);
                powerRangeNode.className = "encounter-power-range";
                divExp.insertAdjacentElement('afterend', powerRangeNode);
            }
            
            var heroPowerClass = "hero-power-rate-";
            var powerDiff = minRollPower - enemyMaxPower;
            //console.log(minRollPower, enemyMaxPower, powerDiff);
            if (powerDiff > 0) {
                heroPowerClass += "1";
            } else {
                var powerRate = Math.abs(powerDiff) / (maxRollPower - minRollPower) * 100;
                if (powerRate < 7) {
                    heroPowerClass += "1";
                } else if (powerRate < 15) {
                    heroPowerClass += "2";
                } else if (powerRate < 30) {
                    heroPowerClass += "3";
                } else {
                    heroPowerClass += "4";
                }
            }
            var heroTitle = "Hero roll power [" + minRollPower + " - " + maxRollPower + "]";
            var enemyTitle = "Enemy roll power [" + enemyMinPower + " - " + enemyMaxPower + "]";
            var powerTitle = heroTitle + "\n" + enemyTitle;

            powerRangeNode.className = "encounter-power-range " + heroPowerClass;
            powerRangeNode.setAttribute("title", powerTitle);
            powerRangeNode.innerText = (powerDiff > 0 ? "+" : "") + powerDiff + " Power";

            // powerRangeNode.innerHTML = "<span class='hero-power' title='" + heroTitle + "'>[H] " + minRollPower + "</span> " + 
            //     "<span class='enemy-power' title='" + enemyTitle + "'>" + enemyMaxPower + " [E]</span>";
            //console.log(minRollPower - enemyMaxPower, maxRollPower - minRollPower);
            var winRate = winMatch / 10;
            winRate = winRate == 100 && enemyMaxPower >= minRollPower ? 99.99 : winRate;
            var fightText = "Fight! (" + winRate.toFixed(2) + "%)";

            var btnFight = d.querySelector("button.encounter-button");
            var btnFightText = btnFight.querySelector("h1");
            if (btnFightText) {
                btnFightText.outerHTML = "<h3>" + fightText + "</h3>";
            } else {
                btnFightText = btnFight.querySelector("h3");
                btnFightText.innerText = fightText;
            }

            var spnFightCount = btnFight.querySelector("span.fight-desc");
            if (!spnFightCount) {
                var spnFightCount = document.createElement("span");
                spnFightCount.className = "fight-desc";
                btnFight.insertBefore(spnFightCount, btnFight.querySelector("h2"));
            }
            spnFightCount.innerText = "x" + stamina;
        });

    }

    var enemyObserver = new MutationObserver((ms) => {
        ms.some(d => {
            if (d.type == "characterData" && ["encounter-power", "xp-gain", "victory-chance"].includes(d.target.parentElement.className)) {
                computeRollPower();
                return true;
            }
        });
    });

    var combatObserver = new MutationObserver((ms, o) => {
        // ms.forEach(d => {
        //     console.log(d.target, d);
        // });
        ms.some(m => {
            if ((m.target.nodeType == Node.ELEMENT_NODE && m.target.className == "combat-enemy-container" && m.addedNodes.length > 0) ||
                //(m.target.nodeType == Node.ELEMENT_NODE && m.target.className == "col" && m.removedNodes.length > 0 && m.removedNodes[0].className == "message-box") ||
                (m.target.nodeType == Node.ELEMENT_NODE && m.addedNodes.length > 0 && m.target.querySelector(".combat-enemy-container"))) {
                var enemyContainers = document.querySelector(".enemy-container");
                if (!enemyContainers) return;

                var encounter = document.querySelector(".encounter-container");
                if (encounter) {
                    enemyObserver.observe(encounter, {
                        subtree: true,
                        characterData: true
                    });
                }

                computeRollPower();
                return true;
            }
        });
    })

    combatObserver.observe(document.querySelector(".content"), {
        subtree: true,
        childList: true
    });

    // @params: div.bonus-power > div, 
    function getWeaponBP(divs) {
        var weaponLB = { LB: 0, "4B": 0, "5B": 0 };
        divs.forEach(d => {
            var spn = d.querySelector("span");
            var lbMatch = spn.innerText.match(/^(\d+)\s+(\w+)$/);
            if (lbMatch.length == 3) {
                var key = lbMatch[2];
                var value = parseInt(lbMatch[1], 10);
                weaponLB[key] = weaponLB[key] + value;
            }
        });

        return weaponLB["LB"] * 15 + weaponLB["4B"] * 30 + weaponLB["5B"] * 60;
    }

    // @param: div.weapon
    function showWeaponBonusPower(el, force = false) {
        var isComputed = el.hasAttribute("bonus-power")
        if (force || !isComputed) {
            var bp = 0;
            el.setAttribute("bonus-power", bp);
            var divBP = el.querySelector("div.bonus-power-ext");
            if (divBP) {
                divBP.remove();
            }

            var divs = el.querySelectorAll("div.bonus-power > div");
            if (divs.length > 0) {
                bp = getWeaponBP(divs);
                //console.log(divs, bp);

                divBP = el.querySelector("div.stats > div").cloneNode(true);
                divBP.className = "bonus-power-ext";

                spns = divBP.querySelectorAll("span");
                spns[0].className = "mr-1 icon bns-icon";
                spns[1].className = "bns";
                spns[1].innerText = "BNS +" + bp;
                el.querySelector("div.stats").insertAdjacentElement("beforeend", divBP);
                el.setAttribute("bonus-power", bp);
            }

            return bp;
        } else {
            return parseInt(el.getAttribute("bonus-power"), 10);
        }
    };

    var weaponObserver = new MutationObserver(ms => {
        ms.forEach(m => {

            // All search for root div with .weapon;

            if (m.target.nodeType == Node.ELEMENT_NODE && m.target.classList.contains("weapon-grid") && m.addedNodes.length > 0) {
                //console.log("1", m.target, m);
                m.target.querySelectorAll(".weapon").forEach(d => showWeaponBonusPower(d));
                return;
            } 
            if (m.target.nodeType == Node.ELEMENT_NODE && m.target.classList.contains("glow-container") && m.addedNodes.length > 0) {
                //console.log("2", m.target, m);
                showWeaponBonusPower(m.target.parentElement.parentElement.parentElement);
                return;
            }
            if (m.target.nodeType == Node.ELEMENT_NODE && m.target.classList.contains("weapon-icon") && m.addedNodes.length > 0) {
                //console.log("3", m.target, m);
                showWeaponBonusPower(m.target.parentElement.parentElement);
                return;
            }
            
            // if (m.addedNodes.length > 0) {
            //     console.log(m.target, m);
            // }
        });
    });

    var debugObserver = new MutationObserver((ms) => {
        ms.forEach(m => console.log(m.target, m));
    });

    // debugObserver.observe(document.body, {
    //     subtree: true,
    //     childList: true
    // });

    function waitForContent() {
        var content = document.querySelector(".content");
        if (content) {
            weaponObserver.observe(content, {
                subtree: true,
                childList: true
            });
        } else {
            setTimeout(waitForContent, 200);
        }
    }

    waitForContent();

    // waitForAddedNode({
    //     className: "content",
    //     parent: document.querySelector(".content"),
    //     done: el => {
    //         console.log('found');
    //         weaponObserver.observe(el, {
    //             subtree: true,
    //             childList: true
    //         });
    //     }
    // });
})();
